package com.lucky.mod;

public class Abilities {
    public static final String[] NAMES = {
            "Omega Beam", "Lightning Storm", "Meteor Shower", "Healing Nova", "Sky Launch", "Item Rain",
            "Gravity Warp", "Ally Summon", "Orbital Strike", "Aegis Shield", "Guardian Legion",
            "Black Hole", "Frost Nova", "Hurricane", "Dragon Breath", "Projectile Storm", "Blink Strike", "Overdrive",
            "Yellow Flight", "Time Stop", "Time Surge", "Void Rift", "Giant Tesseract", "Ally Command",
            "Lucky Ascension", "Reality Break", "Chrono Burst", "Dimension Shift", "Cosmic Nova", "Item Wish",
            "Time Replay", "Spatial Deflection", "Absolute Aegis", "Thunder God"
    };
    public static final int COUNT = NAMES.length;
}
