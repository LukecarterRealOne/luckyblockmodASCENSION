package com.lucky.mod;

import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LuckyBlockMod.MOD_ID)
public class Events {
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        DamageSource src = event.getSource();
        // Absolute Aegis blocks essentially every damage source while active.
        if (LuckyBlockItem.SHIELDED.contains(player.getUUID()) && !src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            event.setCanceled(true);
            return;
        }
        // summoned allies can never damage any player
        Entity attacker = src.getEntity();
        Entity direct = src.getDirectEntity();
        if ((attacker != null && attacker.getTags().contains("lbm_ally"))
                || (direct != null && direct.getTags().contains("lbm_ally"))) {
            event.setCanceled(true);
        }
    }
    @SubscribeEvent
    public static void onLuckyDeath(LivingDeathEvent event) {
        if (!(event.getEntity() instanceof Player player) || player.level().isClientSide) return;
        ItemStack main = player.getMainHandItem();
        ItemStack off = player.getOffhandItem();
        if (!(main.getItem() instanceof LuckyBlockItem) && !(off.getItem() instanceof LuckyBlockItem)) return;
        // The Lucky Block refuses a single fatal blow and triggers its ascension instead.
        event.setCanceled(true);
        player.setHealth(Math.max(1.0f, player.getMaxHealth()));
        player.clearFire();
        player.removeAllEffects();
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 2400, 4));
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 2400, 4));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 2400, 8));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 2400, 5));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 2400, 3));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 2400, 0));
        player.displayClientMessage(net.minecraft.network.chat.Component.literal("§e§lYou Died??"), false);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal("§fWith that much power with you?"), false);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal("§fwow your a noob"), false);
        player.displayClientMessage(net.minecraft.network.chat.Component.literal("§6But aside from that, I won't allow you to die that easily."), false);
        if (player.level() instanceof net.minecraft.server.level.ServerLevel level) {
            Fx.screen(level, player.position(), 100, 1.0f, 4.0f, 30, 0xFFFF00);
            Fx.burst(level, net.minecraft.core.particles.ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY()+1, player.getZ(), 160, 2, 2, 2, .25);
        }
    }

}
