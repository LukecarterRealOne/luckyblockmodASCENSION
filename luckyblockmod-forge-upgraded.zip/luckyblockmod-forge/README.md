# Lucky Block (Forge 1.20.1)

Build: JDK 17 + Gradle 8.8, run `gradle build` -> `build/libs/luckyblockmod-1.0.0.jar`
(or let GitHub Actions build it - see the workflow in the repo instructions).

Install: Minecraft 1.20.1 + Forge 47.x, put the jar in the `mods` folder. No Fabric API needed.

Use: `/give @s luckyblockmod:lucky_block`. Press **G** for the ability menu. Right-click casts the selected
ability (random by default). Sneak + right-click = Omega Beam. This upgraded build adds time/space-themed powers, stronger attacks, wider healing, a yellow ascension aura, and a one-time death-save while holding the item. Item Rain includes registered vanilla and installed-mod items; Item Wish grants a random registry item.
